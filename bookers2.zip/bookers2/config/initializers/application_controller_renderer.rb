# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '6b16bf3dda99c2d23752bf1e185835dc3cbf527eb3462976cdf8c2fafafa434a431033e6fc419ba99565c45b7a74c91d2d8490f1e5c2f2335c9c941283f7806e'